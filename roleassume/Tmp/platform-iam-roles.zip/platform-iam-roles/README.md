# Platform IAM roles: GitHub to AWS

Every platform account (Infrastructure, Security, Sandbox) gets two roles, signed in to in two hops:
GitHub OIDC -> `iamr-<account>-<env>-<deploy|read>` in IMS Root (`390403857119`) -> the same-named role in the account.
`deploy` = AdministratorAccess, `read` = ReadOnlyAccess. Same patterns as `iam-roles-template.yml` and the
Workload account stacks (e.g. `ims-tst-coll-ims-coll`). Each folder holds one `*-template.yml` and its `params.json`.

## Deploy order
1. **IMS Root stacks first** (order 1). An account role's trust policy names its IMS Root role, and IAM rejects
   a trust policy that names a role that does not exist yet ("Invalid principal in policy").
2. **Account stacks** (order 2), each in its own account, in any order.
3. **Check:** run `.github/workflows/check-platform-signin.yml` (choose `All` or one OU). It signs in to every
   account with both roles and creates nothing.

## Stacks
| Order | Stack name | Deploy in | Folder | Creates |
|---|---|---|---|---|
| 1 | `ims-root-iam-roles-infrastructure` | IMS Root `390403857119` | `cloudformation/ims-root/iam-roles-infrastructure/` | 24 roles: iamr-shared-prd-*, iamr-restore-prd-*, iamr-monitoring-prd-*, iamr-imsdirectory-prd-*, iamr-secinfra-prd-*, iamr-directory-prd-*, iamr-backup-prd-*, iamr-shared-ppe-*, iamr-monitoring-ppe-*, iamr-directory-ppe-*, iamr-directory-dev-*, iamr-shared-dev-* |
| 1 | `ims-root-iam-roles-security` | IMS Root `390403857119` | `cloudformation/ims-root/iam-roles-security/` | 4 roles: iamr-audit-prd-*, iamr-logarchive-prd-* |
| 1 | `ims-root-iam-roles-sandbox` | IMS Root `390403857119` | `cloudformation/ims-root/iam-roles-sandbox/` | 2 roles: iamr-sandbox-sbx-* (same files as before) |
| 2 | `ims-prd-shared-ims-shared` | Shared_Services (prd) `356666487118` | `cloudformation/accounts/infrastructure-prd/shared-services/` | iamr-shared-prd-deploy, iamr-shared-prd-read |
| 2 | `ims-prd-restore-ims-restore` | Restore_Services (prd) `899867382346` | `cloudformation/accounts/infrastructure-prd/restore-services/` | iamr-restore-prd-deploy, iamr-restore-prd-read |
| 2 | `ims-prd-net-ims-net` | Network_Services (prd) `584477831165` | `cloudformation/accounts/infrastructure-prd/network-services/` | iamr-net-prd-deploy, iamr-net-prd-read |
| 2 | `ims-prd-monitoring-ims-monitoring` | Monitoring_Services (prd) `116355921084` | `cloudformation/accounts/infrastructure-prd/monitoring-services/` | iamr-monitoring-prd-deploy, iamr-monitoring-prd-read |
| 2 | `ims-prd-imsdirectory-ims-imsdirectory` | IMS Directory Services (prd) `794035561643` | `cloudformation/accounts/infrastructure-prd/ims-directory-services/` | iamr-imsdirectory-prd-deploy, iamr-imsdirectory-prd-read |
| 2 | `ims-prd-secinfra-ims-secinfra` | Security_Infra (prd) `119810927880` | `cloudformation/accounts/infrastructure-prd/security-infra/` | iamr-secinfra-prd-deploy, iamr-secinfra-prd-read |
| 2 | `ims-prd-directory-ims-directory` | Directory_Services (prd) `502818572771` | `cloudformation/accounts/infrastructure-prd/directory-services/` | iamr-directory-prd-deploy, iamr-directory-prd-read |
| 2 | `ims-prd-backup-ims-backup` | Backup_Services (prd) `117837574201` | `cloudformation/accounts/infrastructure-prd/backup-services/` | iamr-backup-prd-deploy, iamr-backup-prd-read |
| 2 | `ims-ppe-net-ims-net` | Network_Services (ppe) `097357356161` | `cloudformation/accounts/infrastructure-ppe/network-services/` | iamr-net-ppe-deploy, iamr-net-ppe-read |
| 2 | `ims-ppe-shared-ims-shared` | Shared_Services (ppe) `050916357979` | `cloudformation/accounts/infrastructure-ppe/shared-services/` | iamr-shared-ppe-deploy, iamr-shared-ppe-read |
| 2 | `ims-ppe-monitoring-ims-monitoring` | Monitoring_Services (ppe) `277352717275` | `cloudformation/accounts/infrastructure-ppe/monitoring-services/` | iamr-monitoring-ppe-deploy, iamr-monitoring-ppe-read |
| 2 | `ims-ppe-directory-ims-directory` | Directory_Services (ppe) `575210791269` | `cloudformation/accounts/infrastructure-ppe/directory-services/` | iamr-directory-ppe-deploy, iamr-directory-ppe-read |
| 2 | `ims-tst-net-ims-net` | Network_Services (tst) `762649987860` | `cloudformation/accounts/infrastructure-tst/network-services/` | iamr-net-tst-deploy, iamr-net-tst-read |
| 2 | `ims-dev-directory-ims-directory` | Directory_Services (dev) `119328599021` | `cloudformation/accounts/infrastructure-dev/directory-services/` | iamr-directory-dev-deploy, iamr-directory-dev-read |
| 2 | `ims-dev-shared-ims-shared` | Shared_Services (dev) `697858908364` | `cloudformation/accounts/infrastructure-dev/shared-services/` | iamr-shared-dev-deploy, iamr-shared-dev-read |
| 2 | `ims-prd-audit-ims-audit` | Core Audit (prd) `084828582217` | `cloudformation/accounts/security/core-audit/` | iamr-audit-prd-deploy, iamr-audit-prd-read |
| 2 | `ims-prd-logarchive-ims-logarchive` | Core Log Archive (prd) `816069122659` | `cloudformation/accounts/security/core-log-archive/` | iamr-logarchive-prd-deploy, iamr-logarchive-prd-read |
| 2 | `ims-sbx-sandbox-ims-sandbox` | Sandbox `036943221440` | `cloudformation/accounts/sandbox/sandbox/` | iamr-sandbox-sbx-deploy, iamr-sandbox-sbx-read |

## Notes
- **Network_Services prd/ppe/tst:** their IMS Root roles (`iamr-net-*`) already exist in the main stack, so they are
  not in the Infrastructure IMS Root stack (a second copy would fail: the names are taken). Deploy the three network
  account stacks only if the roles do not exist in those accounts yet: a stack cannot create a role name that
  already exists. The check workflow shows which is the case.
- **Size:** the Infrastructure IMS Root template is about 65 KB, over CloudFormation's 51,200-byte limit for a
  template sent directly. Upload it in the console (it goes through S3 automatically) or use the pipeline's
  large-template S3 path, as for the main IAM roles stack.
- **Trust:** like the main stack, every new IMS Root role accepts any repo in the 13 GitHub organisations
  (the prd network roles accept only `plat-eng/AWS-Landing-Zone` and `ims-app/ims-app-identity`).
- **Security OU (Core Audit, Core Log Archive):** Control Tower's guardrails exempt `AWSControlTowerExecution` but not
  these roles, so pipelines using them cannot change Control Tower's own resources there.
- **Names:** to rename an account's roles, change both its IMS Root stack and its account stack.
